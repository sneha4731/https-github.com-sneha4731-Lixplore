# blog.py
import sqlite3
from flask import Blueprint, render_template, abort
from markdown import markdown

# Blueprint for blog routes
blog_bp = Blueprint("blog", __name__)

# Database path
DB_PATH = "database/lixplore.db"

def get_blog_by_slug(slug):
    """Fetch a single blog post by its slug."""
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT title, author, content, created_at, tags
            FROM blog_posts
            WHERE slug = ?
        """, (slug,))
        row = cursor.fetchone()

    if row:
        return {
            "title": row[0],
            "author": row[1],
            "content": markdown(row[2]),  # Convert markdown to HTML
            "created_at": row[3],
            "tags": row[4].split(",") if row[4] else []
        }
    return None

def get_all_blogs():
    """Fetch all blog posts."""
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT slug, title, author, created_at, tags
            FROM blog_posts
            ORDER BY created_at DESC
        """)
        rows = cursor.fetchall()

    return [
        {
            "slug": row[0],
            "title": row[1],
            "author": row[2],
            "created_at": row[3],
            "tags": row[4].split(",") if row[4] else []
        }
        for row in rows
    ]

# Route to display all blog posts
@blog_bp.route("/blog")
def blog_list():
    blog_posts = get_all_blogs()
    return render_template("blog_list.html", blogs=blog_posts)

# Route to display a single blog post
@blog_bp.route("/blog/<slug>")
def show_blog(slug):
    blog = get_blog_by_slug(slug)
    if not blog:
        abort(404)
    return render_template("blog.html", blog=blog)

