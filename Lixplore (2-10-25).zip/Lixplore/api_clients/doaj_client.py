import requests

class DOAJClient:
    BASE_URL = "https://doaj.org/api/v2/search/articles/"

    def search(self, query, rows=10):
        """Search DOAJ for open access articles."""
        params = {"q": query, "pageSize": rows}
        try:
            r = requests.get(self.BASE_URL, params=params, timeout=15)
            r.raise_for_status()
        except requests.exceptions.RequestException as e:
            print(f"⚠ DOAJ API error: {e}")
            return []

        items = r.json().get("results", [])
        results = []
        for item in items:
            bibjson = item.get("bibjson", {})
            results.append({
                "title": bibjson.get("title", "No title"),
                "authors": [a.get("name", "") for a in bibjson.get("author", [])],
                "doi": next((i.get("id") for i in bibjson.get("identifier", []) if i.get("type") == "doi"), ""),
                "url": next((l.get("url") for l in bibjson.get("link", [])), ""),
                "source": "DOAJ"
            })
        return results