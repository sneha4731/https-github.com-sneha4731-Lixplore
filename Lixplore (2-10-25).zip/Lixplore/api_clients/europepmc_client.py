import requests

class EuropePMCClient:
    BASE_URL = "https://www.ebi.ac.uk/europepmc/webservices/rest/search"

    def search(self, query, rows=10):
        """Search EuropePMC for articles."""
        params = {"query": query, "format": "json", "pageSize": rows}
        try:
            r = requests.get(self.BASE_URL, params=params, timeout=15)
            r.raise_for_status()
        except requests.exceptions.RequestException as e:
            print(f"⚠ EuropePMC API error: {e}")
            return []

        items = r.json().get("resultList", {}).get("result", [])
        results = []
        for item in items:
            results.append({
                "title": item.get("title", "No title"),
                "authors": item.get("authorString", "").split(", "),
                "doi": item.get("doi", ""),
                "url": item.get("fullTextUrlList", {}).get("fullTextUrl", [{}])[0].get("url", ""),
                "source": "EuropePMC"
            })
        return results