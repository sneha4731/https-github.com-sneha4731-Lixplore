import requests

class SpringerClient:
    BASE_URL = "http://api.springernature.com/metadata/json"

    def __init__(self, api_key="YOUR_SPRINGER_API_KEY"):
        self.api_key = api_key

    def search(self, query, rows=10):
        """Search Springer Nature API for articles."""
        params = {"q": query, "p": rows, "api_key": self.api_key}
        try:
            r = requests.get(self.BASE_URL, params=params, timeout=15)
            r.raise_for_status()
        except requests.exceptions.RequestException as e:
            print(f"⚠ Springer API error: {e}")
            return []

        items = r.json().get("records", [])
        results = []
        for item in items:
            results.append({
                "title": item.get("title", "No title"),
                "authors": [a.get("creator", "") for a in item.get("creators", [])],
                "doi": item.get("doi", ""),
                "url": item.get("url", [{}])[0].get("value", ""),
                "source": "Springer"
            })
        return results