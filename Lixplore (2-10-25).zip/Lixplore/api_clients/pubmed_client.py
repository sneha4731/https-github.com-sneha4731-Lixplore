import requests

class PubMedClient:
    BASE_URL = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi"
    SUMMARY_URL = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi"

    def search(self, term, retmax=10):
        """Search PubMed articles by keyword"""
        params = {
            "db": "pubmed",
            "term": term,
            "retmode": "json",
            "retmax": retmax
        }
        try:
            r = requests.get(self.BASE_URL, params=params, timeout=20)
            r.raise_for_status()
        except requests.exceptions.RequestException as e:
            print(f"⚠ PubMed API error: {e}")
            return []

        ids = r.json().get("esearchresult", {}).get("idlist", [])
        if not ids:
            return []

        summaries = requests.get(
            self.SUMMARY_URL,
            params={"db": "pubmed", "id": ",".join(ids), "retmode": "json"},
            timeout=20
        ).json()

        results = []
        for uid in ids:
            doc = summaries.get("result", {}).get(uid, {})
            results.append({
                "title": doc.get("title", "No title available"),
                "authors": [a.get("name", "") for a in doc.get("authors", [])],
                "url": f"https://pubmed.ncbi.nlm.nih.gov/{uid}/",
                "source": "PubMed"
            })
        return results