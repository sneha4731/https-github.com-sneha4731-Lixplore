import requests

class CrossrefClient:
    BASE_URL = "https://api.crossref.org/works"

    def search(self, query, rows=10):
        """Search Crossref for works"""
        params = {
            "query": query,
            "rows": rows
        }
        response = requests.get(self.BASE_URL, params=params, timeout=10)
        response.raise_for_status()
        data = response.json()

        results = []
        for item in data.get("message", {}).get("items", []):
            results.append({
                "title": item.get("title", ["No title"])[0],
                "authors": [f"{a.get('given', '')} {a.get('family', '')}".strip()
                            for a in item.get("author", [])],
                "doi": item.get("DOI"),
                "url": item.get("URL"),
                "year": item.get("issued", {}).get("date-parts", [[None]])[0][0],
                "abstract": item.get("abstract")
            })
        return results
