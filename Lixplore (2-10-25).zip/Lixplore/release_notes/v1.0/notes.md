# Test Release – v0.0.1

### ✨ Added
- Initial version of the literature search tool
- PubMed integration with keyword and PMID search

### 🐛 Fixed
- Minor bugs during DOI parsing

### 📅 Date
2025-08-07

---

This is a test release note written in **Markdown**.

